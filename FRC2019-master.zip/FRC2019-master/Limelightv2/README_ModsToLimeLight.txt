Adjustment to LED Board brightness - REQUIRED:
#################################################
On LED carrier board, there is a 150Ω resistor on each side that's feedback to the high side driver chips.
This must be replaced with a 1kΩ resistor in order to achieve the correct brightness for our pipelines and prevent overexposure.


#################################################