package com.team195.lib.util;

import java.util.List;

public interface Reportable {
	List<Object> generateReport();
}
