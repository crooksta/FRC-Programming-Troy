package com.team195.frc2019.loops;

public interface ILooper {
    void register(Loop loop);
}
