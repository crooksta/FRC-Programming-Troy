package com.team195.lib.util;

public interface CriticalSystemStatus {
	boolean isSystemFaulted();
}
