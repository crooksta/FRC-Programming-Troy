package com.team195.lib.util;

public interface InterferenceSystem {
	double getPosition();
	double getSetpoint();
}
