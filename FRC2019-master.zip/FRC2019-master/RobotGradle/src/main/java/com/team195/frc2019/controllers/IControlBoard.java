package com.team195.frc2019.controllers;

import com.team195.frc2019.controlboard.IButtonControlBoard;
import com.team195.frc2019.controlboard.IDriveControlBoard;

public interface IControlBoard extends IDriveControlBoard, IButtonControlBoard {
}